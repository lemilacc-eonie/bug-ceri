global.prefa = ['','!','.',',','🐤','🗿']
global.owner = ['6285696558295']
global.gambar = ""
// GANTI NO OWNER DENGAN NOMOR MU LALU RUNN SEPERTI BIASA !!!